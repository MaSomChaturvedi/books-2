/**
 * 
 */
package com.iris.poc.camel.publisher;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

/**
 * @author Som Nath
 *
 */
@Component
public class PublisherRoute extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		this.initPublish();

	}
	private void initPublish() {
		StringBuilder params=new StringBuilder();
		params.append("${exchangeProperty.EMPLOYEE_LOAD[first_name]}").append("\n").append("${exchangeProperty.EMPLOYEE_LOAD[contact_number]}").append("\n")
		.append("${exchangeProperty.EMPLOYEE_LOAD[country]}").append("\n").append("${exchangeProperty.EMPLOYEE_LOAD[zip]}");
		from("direct:publishRouter").routeId("publishRouteId").log(params.toString());
	}
}
