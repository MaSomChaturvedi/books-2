package com.iris.poc.camel.route;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.iris.poc.camel.processor.EmployeeProcessor;
import com.iris.poc.camel.processor.ValidationProcessor;

@Component
public class ConsumerRoute extends BaseRoute {
	@Autowired
	private EmployeeProcessor employeeProcessor;
	@Autowired
	private ValidationProcessor validationProcesor;
	/*
	 * @Override public void configure() throws Exception { super.configure();
	 * from("file:E:\\data").routeId("ConsumerRoute").onException(Exception.class).
	 * handled(true).to("direct:logException").end().process(employeeProcessor).to(
	 * "direct:logSuccess").end(); } private void initilizeEmployeeRoute() {
	 * //from("direct:em") }
	 */
	
	@Override
	public void configure() throws Exception {
		super.configure();
		//initEmployee();
		from("file:E:\\data").routeId("ConsumerRoute").process(employeeProcessor)//.choice()
				//.when(simple("${exchangeProperty.IS_MANAGER} == false")).log("No Manager found").otherwise()
				.to("direct:publishRouter").end();
				//.otherwise()
				//.log("No manager data found").end();
		
	}

	private void initEmployee() {
		from("direct:employeeProcessor").routeId("EmployeeProcessor").onException(Exception.class).handled(true)
				.to("direct:logException").end().process(employeeProcessor).choice()
				.when(simple("${exchangeProperty.EMPLOYEE_LOAD} != null")).to("direct:publishRouter").otherwise()
				.log("No manager data found").end();
	}
}
