package com.iris.poc.camel.route;

import org.apache.camel.builder.RouteBuilder;

public class BaseRoute extends RouteBuilder {

	@Override
	public void configure() throws Exception {
		onException(Exception.class).handled(true).to("direct:logException").end();

	}

}
