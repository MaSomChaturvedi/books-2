package com.iris.poc.camel.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages="com.iris.poc.camel")
public class PocAdapterApplication {

	public static void main(String[] args) {
		SpringApplication.run(PocAdapterApplication.class, args);

	}

}
