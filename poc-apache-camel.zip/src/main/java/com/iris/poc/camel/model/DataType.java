package com.iris.poc.camel.model;

public enum DataType {
	BIGDECIMAL("bigdecimal"), BOOLEAN("boolean"), INTEGER("integer");

	String value;

	DataType(String value) {
		this.value = value;
	}

	public String getValue() {
		return this.value;
	}

	public boolean equals(String value) {
		return this.getValue().equals(value);
	}

}
