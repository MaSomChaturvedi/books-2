package com.iris.poc.camel.route;

import org.apache.camel.builder.RouteBuilder;

public class LogRoute extends RouteBuilder{

	@Override
	public void configure() throws Exception {
		from("direct:logException").routeId("ExceptionLogRoute").log("Exception Occur while processing xml").end();
		from("direct:logSuccess").routeId("SuccessLogRoute").log("Successfully Process Xml").end();
	}

}
