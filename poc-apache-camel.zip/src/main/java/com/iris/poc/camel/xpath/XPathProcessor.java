/**
 * 
 */
package com.iris.poc.camel.xpath;

import java.io.StringReader;
import java.lang.invoke.MethodHandles;
import java.math.BigDecimal;

import javax.xml.transform.stream.StreamSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.iris.poc.camel.exception.XpathException;

import net.sf.saxon.om.GroundedValue;
import net.sf.saxon.om.Item;
import net.sf.saxon.s9api.Processor;
import net.sf.saxon.s9api.SaxonApiException;
import net.sf.saxon.s9api.XPathCompiler;
import net.sf.saxon.s9api.XdmNode;
import net.sf.saxon.s9api.XdmValue;
import net.sf.saxon.trans.XPathException;

/**
 * @author Som Nath
 *
 */
public class XPathProcessor {

	private static final Logger LOGGER = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass().getName());

	private Processor processor;
	private XdmNode xmlNode;
	private XPathCompiler xPathCompiler;

	public XPathProcessor(String xml) throws SaxonApiException {
		processor = new Processor(false);
		xmlNode = processor.newDocumentBuilder().build(new StreamSource(new StringReader(xml)));
		xPathCompiler = processor.newXPathCompiler();
	}

	public String evaluateStringValue(String xPath) throws XpathException {
		try {
			XdmValue result = xPathCompiler.evaluate(xPath, xmlNode);
			String value = null;
			if (result.getUnderlyingValue().getLength() > 1) {
				value = getFirstValue(result.getUnderlyingValue());
			} else {
				value = result.getUnderlyingValue().getStringValue();
			}
			return (value == null || value.isEmpty()) ? null : value;
		} catch (SaxonApiException | XPathException e) {
			LOGGER.error("Exception occurred while evaluating xpath {}", xPath);
			throw new XpathException(e);
		}
	}

	public Boolean evaluateBooleanValue(String xPath) throws XpathException {
		try {
			XdmValue result = xPathCompiler.evaluate(xPath, xmlNode);

			String value = null;

			if (result.getUnderlyingValue().getLength() > 1) {
				value = getFirstValue(result.getUnderlyingValue());
			} else {
				value = result.getUnderlyingValue().getStringValue();
			}

			return (value == null || value.isEmpty()) ? null : Boolean.valueOf(value);
		} catch (SaxonApiException | XPathException e) {
			LOGGER.error("Exception occurred while evaluating xpath {}", xPath);
			throw new XpathException(e);
		}
	}

	public BigDecimal evaluateBigDecimal(String xPath) throws XpathException {
		try {
			XdmValue result = xPathCompiler.evaluate(xPath, xmlNode);
			String value = null;

			if (result.getUnderlyingValue().getLength() > 1) {
				value = getFirstValue(result.getUnderlyingValue());
			} else {
				value = result.getUnderlyingValue().getStringValue();
			}

			if (value != null && !value.isEmpty()) {
				return new BigDecimal(value);
			}
		} catch (SaxonApiException | XPathException e) {
			LOGGER.error("Exception occurred while evaluating xpath {}", xPath);
			throw new XpathException(e);
		}
		return null;
	}

	public Integer evaluateInteger(String xPath) throws XpathException {
		try {
			XdmValue result = xPathCompiler.evaluate(xPath, xmlNode);

			String value = null;

			if (result.getUnderlyingValue().getLength() > 1) {
				value = getFirstValue(result.getUnderlyingValue());
			} else {
				value = result.getUnderlyingValue().getStringValue();
			}

			if (value != null && !value.isEmpty()) {
				return Integer.valueOf(value);
			}
		} catch (SaxonApiException | XPathException e) {
			LOGGER.error("Exception occurred while evaluating xpath {}", xPath);
			throw new XpathException(e);
		}
		return null;
	}

	private String getFirstValue(GroundedValue<?> underlyingValues) {
		Item<?> item = underlyingValues.itemAt(0);
		return item.getStringValue();
	}

}
