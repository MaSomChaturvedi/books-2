package com.iris.poc.camel.processor;

import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.iris.poc.camel.model.DataType;
import com.iris.poc.camel.model.KeyValueModel;
import com.iris.poc.camel.util.XmlUtil;
import com.iris.poc.camel.xpath.XPathProcessor;

@Component
public class EmployeeProcessor implements Processor {
	@Value("classpath:mapping/company-mapping.json")
	private Resource employeeMapping;

	@Override
	public void process(Exchange exchange) throws Exception {
		String xml = exchange.getIn().getBody(String.class);
		xml = XmlUtil.removeXmlStringNamespaceAndPreamble(xml);
		XPathProcessor xPathProcessor = new XPathProcessor(xml);
		Gson gson = new Gson();
		List<KeyValueModel> xpathMapping = gson.fromJson(new InputStreamReader(employeeMapping.getInputStream()),
				new TypeToken<ArrayList<KeyValueModel>>() {
				}.getType());
		Map<String, Object> employeeMap = new HashMap<>();
		for (KeyValueModel mapping : xpathMapping) {
			if (mapping.getValue() != null) {
				employeeMap.put(mapping.getKey(), mapping.getValue());
			} else {
				if (DataType.BIGDECIMAL.equals(mapping.getType())) {
					employeeMap.put(mapping.getKey(), xPathProcessor.evaluateBigDecimal(mapping.getXpath()));
				} else if (DataType.BOOLEAN.equals(mapping.getType())) {
					employeeMap.put(mapping.getKey(), xPathProcessor.evaluateBooleanValue(mapping.getXpath()));

				} else if (DataType.INTEGER.equals(mapping.getType())) {
					employeeMap.put(mapping.getKey(), xPathProcessor.evaluateInteger(mapping.getXpath()));
				} else {
					employeeMap.put(mapping.getKey(), xPathProcessor.evaluateStringValue(mapping.getXpath()));
				}
			}
		}
		exchange.setProperty("EMPLOYEE_LOAD", employeeMap);
	}

}
