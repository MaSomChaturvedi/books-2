package com.iris.poc.camel.exception;

public class XpathException extends Exception {
	private static final long serialVersionUID = 1L;
	public XpathException() {
		super();
	}

	public XpathException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public XpathException(String message, Throwable cause) {
		super(message, cause);
	}

	public XpathException(String message) {
		super(message);
	}

	public XpathException(Throwable cause) {
		super(cause);
	}

}
