package com.iris.poc.camel.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

import com.iris.poc.camel.util.XmlUtil;
import com.iris.poc.camel.xpath.XPathProcessor;

@Component
public class ValidationProcessor implements Processor {
	//@Value("${xpath.isManager}")
	private String isManager="if(//Company/Employee[@type='Manager']) then true() else false()";

	@Override
	public void process(Exchange exchange) throws Exception {
		String xml = exchange.getIn().getBody(String.class);
		xml = XmlUtil.removeXmlStringNamespaceAndPreamble(xml);
		XPathProcessor xPathProcessor = new XPathProcessor(xml);
		Boolean manager=xPathProcessor.evaluateBooleanValue(isManager);
		exchange.setProperty("IS_MANAGER", manager);
		exchange.getIn().setBody(xml);
	}

}
